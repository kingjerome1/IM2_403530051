package maze;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.UIManager;

public class Final_project extends JFrame implements ActionListener{
    
    private static final long serialVersionUID = 1L;
    
    public static void main(String[] args) {
        new Final_project().setVisible(true);
    }
    
    private Final_project(){
        super("final project");
        setSize(600,600);
        setResizable(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //setLayout(new FlowLayout());
        setLayout(new GridLayout(2,1));
        
        JMenuBar bar = new JMenuBar();
        JMenu file = new JMenu("檔案");
        JMenuItem newMenuItem = new JMenuItem("關於");
        setJMenuBar(bar);
        file.add(newMenuItem);
        bar.add(file);
        
        JButton Button = new JButton("開始");
        JButton Button2 = new JButton("結束");
        Button.addActionListener(this);
        Button2.addActionListener(this);
        add(Button);
        add(Button2);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String name = e.getActionCommand();
        
        if(name.equals("開始")){
            String output = "程式開始運作\n";
            char[][] m = {
               {'*', ' ', '*', '*', '*', '*', '*', '*', '*'}, 
               {'*', ' ', ' ', ' ', ' ', ' ', '*', ' ', '*'}, 
               {'*', ' ', '*', '*', '*', '*', '*', ' ', '*'}, 
               {'*', ' ', '*', ' ', '*', ' ', ' ', ' ', '*'}, 
               {'*', ' ', '*', ' ', '*', '*', '*', ' ', '*'}, 
               {'*', ' ', ' ', ' ', '*', ' ', ' ', ' ', '*'}, 
               {'*', '*', '*', ' ', '*', ' ', '*', '*', '*'}, 
               {'*', ' ', ' ', '*', ' ', ' ', '*', ' ', '*'}, 
               {'*', '*', '*', '*', '*', '*', '*', ' ', '*'}};
               
            Maze maze = new Maze(m);
            ShowMaze showmaze = new ShowMaze(m); 
           
            
            output+="Example1: Start from (4,3) \n";
            output+="Expected: true\n";
            output+="Result:" + maze.escape(4,3)+"\n";
            showmaze.showm();
            showmaze.show();
            output += showmaze.toString();
            
            if(maze.escape(4,3)){
          	  for(int i=maze.path.size()-1;i>=0;i--){
          		output +=maze.path.get(i).xy()+"\n";
          	  }
          	output +="\n\n";
            }
            
            showmaze.clear();
            
            output +="Example2: Start from (5,5)\n";
            output +="Expected: false\n";
            output +="Result:" + maze.escape(5,5)+"\n";
            showmaze.showm();
            showmaze.show();
            output+=showmaze.ToString();
            
            if(maze.escape(5,5))
          	  for(int i=maze.path.size()-1;i>=0;i--){
          		output +=maze.path.get(i).xy()+"\n";
          	  }output+="\n\n";
          	  
          	Font font = new Font(Font.SANS_SERIF, Font.PLAIN, 32);  	
        	UIManager.put("OptionPane.buttonFont", font);
        	
        	
            JTextArea textArea = new JTextArea(output);
            textArea.setFont(textArea.getFont().deriveFont(Font.BOLD, 32));
            
            JScrollPane scrollPane = new JScrollPane(textArea);  
            textArea.setLineWrap(true);  
            textArea.setWrapStyleWord(true); 
            scrollPane.setPreferredSize( new Dimension( 1000, 800 ) );
            
            JOptionPane.showMessageDialog(null, scrollPane, "The Maze Solution",  
            		JOptionPane.INFORMATION_MESSAGE);
           
            
        }else if (name.equals("結束")){
            System.exit(0);
        }        
    }
    
}
