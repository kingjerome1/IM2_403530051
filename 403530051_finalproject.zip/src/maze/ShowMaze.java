package maze;

public class ShowMaze {
	char[][] maze;
	char[][] m = {
	         {'*', ' ', '*', '*', '*', '*', '*', '*', '*'}, 
	         {'*', ' ', ' ', ' ', ' ', ' ', '*', ' ', '*'}, 
	         {'*', ' ', '*', '*', '*', '*', '*', ' ', '*'}, 
	         {'*', ' ', '*', ' ', '*', ' ', ' ', ' ', '*'}, 
	         {'*', ' ', '*', ' ', '*', '*', '*', ' ', '*'}, 
	         {'*', ' ', ' ', ' ', '*', ' ', ' ', ' ', '*'}, 
	         {'*', '*', '*', ' ', '*', ' ', '*', '*', '*'}, 
	         {'*', ' ', ' ', '*', ' ', ' ', '*', ' ', '*'}, 
	         {'*', '*', '*', '*', '*', '*', '*', ' ', '*'}};
	private String output = "";
	
	public ShowMaze(char[][] maze){
		this.maze = maze;
	}
	public void showm(){
		output +="========SHOW MAZE======\n\n";
		for(int i=0;i< m.length;i++){	
			for(int j=0;j< m[i].length;j++){
				output +=this.m[i][j];
			}output +="\n";
		}
		output +="==========End===========\n\n";
	}
	
	public void show(){
		output +="========SHOW PATH======\n\n";
		for(int i=0;i< maze.length;i++){	
			for(int j=0;j< maze[i].length;j++){
				output +=this.maze[i][j];
			}output +="\n";
		}
		output +="==========End===========\n\n";	
	}
	
	public String ToString() {
		
		return output;
	};
	
	public void clear(){
		for(int i=0;i< maze.length;i++){	
			for(int j=0;j< maze[i].length;j++){
				if(this.maze[i][j] != '*')this.maze[i][j] =' ';
			}	
		}	
	}
}
