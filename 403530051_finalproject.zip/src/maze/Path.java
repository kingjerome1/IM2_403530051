package maze;

public class Path {
	int x;
	int y;
	
	Path(int x, int y){
		this.x=x;
		this.y=y;
	}
	public String xy(){	
		return "(" + x + "," + y + ")" ;
	}
}
